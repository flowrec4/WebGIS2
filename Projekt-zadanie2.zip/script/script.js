require([
    "esri/Map", 
    "esri/views/SceneView", 
    "esri/layers/FeatureLayer",
    "esri/Graphic",
    "esri/layers/GraphicsLayer",
    "esri/widgets/BasemapGallery",
    "esri/widgets/Expand"
], (Map, Sceneview, FeatureLayer, Graphic, GraphicsLayer, BasemapGallery, Expand) => { 

    const f1 = new FeatureLayer({
        url: "https://services.arcgis.com/ue9rwulIoeLEI9bj/ArcGIS/rest/services/Earthquakes/FeatureServer/0"
    });

    const f2 = new FeatureLayer({
        url: "https://services.arcgis.com/ue9rwulIoeLEI9bj/ArcGIS/rest/services/Earthquakes/FeatureServer/0"
    });

    let graphLayer = new GraphicsLayer();

    const map1 = new Map({ 
        basemap: "streets-night-vector", 
        layers: [f2, graphLayer]    
    });

    const view = new Sceneview({ 
        map: map1,
        container: "mapDiv", 
        center: [-98.57, 39.82], 
        zoom: 3
    });


    const basemapGalleryWg = new BasemapGallery({
        view: view
    });

    const expWg = new Expand({
        view: view,
        content: basemapGalleryWg
    });
    
    view.ui.add(expWg, {position: "top-right"});

    let query = f1.createQuery();
    query.where = "MAGNITUDE > 4";
    query.outFields = ["*"];
    query.returnGeometry = true;

    f1.queryFeatures(query)
    .then(response => {
        console.log(response);
        getResults(response.features)
    })


    function getResults(features){
        const symbol = {
            type: "simple-marker",
            size: 10,
            color: "red"
        };

        features.map(elem => {
            elem.symbol = symbol
        });

        graphLayer.addMany(features);
    }

    let simpleRenderer = {
        type: "simple",
        symbol: {
            type: "point-3d",
            symbolLayers: [
                {
                    type: "object",
                    resource: {
                        primitive: "cylinder"
                    },
                    width: 5000
                }
            ]
        },
        visualVariables: [
            {
                type: "color",
                field: "MAGNITUDE",
                stops: [
                    {
                        value: 0.5,
                        color: "green"
                    },
                    {
                        value: 4.48,
                        color: "red"
                    }
                ]
            },
            {
                type: "size",
                field: "DEPTH",
                stops: [{
                    value: -3.39,
                    size: 50000
                },
                {
                    value: 30.97,
                    size: 100000
                }
            ]
            }
        ]
    };

    f2.renderer = simpleRenderer;
});