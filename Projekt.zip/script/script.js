require([
    "esri/Map", 
    "esri/views/MapView", 
    "esri/layers/FeatureLayer",
    "esri/widgets/BasemapGallery",
    "esri/widgets/Expand",
    "esri/widgets/LayerList",
    "esri/widgets/Legend",
    "esri/widgets/Measurement",
    "esri/widgets/Search"
], (Map, Mapview, FeatureLayer, BasemapGallery, Expand, LayerList, Legend, Measurement, Search) => { 

    const layer = new FeatureLayer({
        portalItem: {  
            id: "d9013310bcd445368fb3afa61d87eb75"
          },
          popupTemplate: {  
            title: "{Nazwa}",
            content:
            "<b>Data otwarcia: </b>{Data_otwar}" + 
            "<br><b>Pojemność (ilość miejsco): </b>{Pojemnosc}" +
            "<br><b>Wymiary boiska: </b>{Wymiary_bo}" +
            "<br><b>Drużyna rozgrywająca mecze na stadionie: </b>{Klub}" +
            "<img src='{url_img}'>"
        }
    });

    const layer2 = new FeatureLayer({
        portalItem: {  
            id: "d72ada6b6d3c41069c0932c7e1dca516"
          },
          popupTemplate: {  
            title: "{Nazwa}",
            content:
            "<b>Data otwarcia: </b>{Data_otwar}" + 
            "<br><b>Pojemność (ilość miejsc): </b>{Pojemnosc}" +
            "<br><b>Wymiary boiska: </b>{Wymiary}" +
            "<br><b>Drużyna rozgrywająca mecze na stadionie: </b>{Klub}" +
            "<img src='{url_img}'>"
        }
    });

    const map1 = new Map({
        basemap: "osm", 
        layers: [layer, layer2]     
    });

    const view = new Mapview({ 
        map: map1,
        container: "mapDiv", 
        center: [19, 52], 
        zoom: 6
    });

    let signal = document.getElementById("signal");

    signal.addEventListener("click", function(){
        view.goTo({
            center: [7.446506, 51.514714],
            zoom: 10
        })
    });

    let sdf = document.getElementById("sdf");

    sdf.addEventListener("click", function(){
        view.goTo({
            center: [2.338072, 48.960497],
            zoom: 10
        })
    });

    let wembley = document.getElementById("wembley");

    wembley.addEventListener("click", function(){
        view.goTo({
            center: [-0.287096, 51.603402],
            zoom: 10
        })
    });

    let sansiro = document.getElementById("sansiro");

    sansiro.addEventListener("click", function(){
        view.goTo({
            center: [9.149318, 45.501661],
            zoom: 10
        })
    });

    let campnou = document.getElementById("campnou");

    campnou.addEventListener("click", function(){
        view.goTo({
            center: [2.107483, 41.386533],
            zoom: 10
        })
    });

    const searchWidget = new Search({
        view: view,
        allPlaceholder: "Adres lub nazwa obiektu",
        includeDefaultSources: true,
        sources: [
            {
              layer: layer,
              searchFields: ["Nazwa"],
              displayField: "Nazwa",
              exactMatch: false,
              outFields: ["Nazwa"],
              name: "Stadiony - Europa",
              placeholder: "np. Camp Nou"
            },
            {
                layer: layer2,
                searchFields: ["Nazwa"],
                displayField: "Nazwa",
                exactMatch: false,
                outFields: ["Nazwa"],
                name: "Stadiony - Polska",
                placeholder: "np. Stadion Górnika Łęczna"
              }
            ]
    });

    const basemapGalleryWg = new BasemapGallery({
        view: view
    });

    const expWg = new Expand({
        view: view,
        content: basemapGalleryWg
    });

    const layerListWg = new LayerList({
        view: view
      });

      const explLWg = new Expand({
        view: view,
        content: layerListWg
    });

      const legendWg = new Legend({
          view: view
      });

      const explWg = new Expand({
        view: view,
        content: legendWg
    });

    const measurementWg = new Measurement({
        viewModel: {
            view: view,
            activeTool: "distance"
          }
      });
      
    const expmWg = new Expand({
        view: view,
        content: measurementWg
    });

    view.ui.add([searchWidget, expWg, explLWg, explWg, expmWg], {
        position: "top-right"
    });
});